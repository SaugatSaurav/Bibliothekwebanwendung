package hbv.web;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

import java.io.*;
import java.sql.*;

import javax.sql.*;
import javax.naming.*;

public class MitarbeiterBenachrichtigungServlet extends HttpServlet {


    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException, ServletException {

        response.setContentType("application/json;charset=UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("management_standort_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        int standortId = (Integer) session.getAttribute("management_standort_id");

        try {

            Context initCtx = new InitialContext();

            DataSource ds =(DataSource) initCtx.lookup("java:/comp/env/jdbc/mariadb");
            Connection connection = ds.getConnection();

            BibliothekAutomatikService.aktualisiereGebuehrFehltageUndSperre(connection);


           
        /*Reservierte Exemplare von Mitglieder holen*/

            String query =
                "SELECT " +
                "m.Mitglied_id AS mitglied_id, " +
                "m.vorname AS vorname, " +
                "m.nachname AS nachname, " +
                "e.id AS exemplar_id, " +
                "b.titel AS titel, " +
                "b.autor AS autor, " +
                "e.barcode AS barcode, " +
                "s.name AS standort, " +
                "e.regal AS regal " +

                "FROM reservierung r " +

                "JOIN mitglied m " +
                "ON r.mitglied_id = m.Mitglied_id " +

                "JOIN exemplar e " +
                "ON r.exemplar_id = e.id " +

                "JOIN buch b " +
                "ON e.buch_id = b.id " +

                "JOIN standort s " +
                "ON e.standort_id = s.id " +

                "WHERE r.status = 'RESERVIERT' " +
                "AND e.verfuegbar = 3 " +
                "AND e.standort_id = ? " +

                "ORDER BY m.Mitglied_id, r.reserviert_am";

            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, standortId);

            ResultSet rs = ps.executeQuery();
            PrintWriter out = response.getWriter();

            out.print("[");

            boolean first = true;

            while (rs.next()) {

                if (!first) {
                    out.print(",");
                }

                String mitgliedName = rs.getString("vorname") + " " + rs.getString("nachname");

                out.print("{");

                out.print(
                    "\"mitgliedId\":" +
                    rs.getInt("mitglied_id") +
                    ","
                );

                out.print(
                    "\"mitgliedName\":\"" +
                    jsonText(mitgliedName) +
                    "\","
                );

                out.print(
                    "\"exemplarId\":" +
                    rs.getInt("exemplar_id") +
                    ","
                );

                out.print(
                    "\"titel\":\"" +
                    jsonText(rs.getString("titel")) +
                    "\","
                );

                out.print(
                    "\"autor\":\"" +
                    jsonText(rs.getString("autor")) +
                    "\","
                );

                out.print(
                    "\"barcode\":\"" +
                    jsonText(rs.getString("barcode")) +
                    "\","
                );

                out.print(
                    "\"standort\":\"" +
                    jsonText(rs.getString("standort")) +
                    "\","
                );

                out.print(
                    "\"regal\":\"" +
                    jsonText(rs.getString("regal")) +
                    "\""
                );

                out.print("}");

                first = false;
            }

            out.print("]");

            rs.close();
            ps.close();
            connection.close();

        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }






    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {

        response.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null ||
            session.getAttribute("management_standort_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.println("Nicht eingeloggt.");
            return;
        }


        String mitgliedIdText = request.getParameter("mitgliedid");

      
        int mitgliedId;
        int standortId;

  

            mitgliedId = Integer.parseInt(mitgliedIdText);

            standortId = (Integer) session.getAttribute("management_standort_id");

       
        Connection connection = null;

        try {

            Context initCtx = new InitialContext();

            DataSource ds =(DataSource) initCtx.lookup("java:/comp/env/jdbc/mariadb");

            connection = ds.getConnection();
            connection.setAutoCommit(false);

            String query =
                "UPDATE reservierung r " +
                "JOIN exemplar e " +
                "ON r.exemplar_id = e.id " +
                "SET r.status = 'AUSGELIEHEN', " +
                "r.reserviert_am = CURDATE(), " +
                "r.zurueckgeben = DATE_ADD(CURDATE(), INTERVAL 4 WEEK), " +
              //"r.zurueckgeben = DATE_ADD(CURDATE(), INTERVAL 1 DAY), " +
                "e.verfuegbar = 0 " +
                "WHERE r.mitglied_id = ? " +
                "AND r.status = 'RESERVIERT' " +
                "AND e.verfuegbar = 3 " +
                "AND e.standort_id = ?";

            PreparedStatement ps =
                connection.prepareStatement(query);

            ps.setInt(1, mitgliedId);
            ps.setInt(2, standortId);

            int count = ps.executeUpdate();

            if (count > 0) {

                connection.commit();
                response.setStatus(HttpServletResponse.SC_OK);
                out.println(count + "Exemplare wurden ausgeliehen.");

            } else {

                connection.rollback();
                response.setStatus(HttpServletResponse.SC_CONFLICT);
                out.println("Keine Benachrichtigung");
            }

            ps.close();

        } catch (SQLException | NamingException e) {

            e.printStackTrace();

            if (connection != null) {

                try {
                    connection.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }

            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            out.println("Serverfehler beim Ausleihen.");

        } finally {

            if (connection != null) {

                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private String jsonText(String text) {

        if (text == null) {
            return "";
        }

        return text
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", " ")
            .replace("\r", " ");
    }
}
