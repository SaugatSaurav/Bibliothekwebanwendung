package hbv.web.QRCode;

import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.BarcodeQRCode;

public class QRCodeGenerator {

    public static Image generateQRCode(String data) {

        try {

            BarcodeQRCode qrCode =new BarcodeQRCode(data, 250, 250, null);

            Image qrImage =qrCode.getImage();
            qrImage.scaleAbsolute(100, 100);
            return qrImage;

        } catch (Exception e) {
            throw new RuntimeException("Fehler beim Erstellen des QR-Codes",e);
        }
    }
}
